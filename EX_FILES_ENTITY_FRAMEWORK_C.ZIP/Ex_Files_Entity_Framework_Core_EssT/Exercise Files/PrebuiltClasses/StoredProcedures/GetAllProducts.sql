CREATE PROCEDURE uspGetAllProducts
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ProductID,
           Name,
           ProductNumber,
           MakeFlag,
           FinishedGoodsFlag,
           Color,
           SafetyStockLevel,
           ReorderPoint,
           StandardCost,
           ListPrice,
           Size,
           SizeUnitMeasureCode,
           WeightUnitMeasureCode,
           Weight,
           DaysToManufacture,
           ProductLine,
           Class,
           Style,
           ProductSubcategoryID,
           ProductModelID,
           SellStartDate,
           SellEndDate,
           DiscontinuedDate,
           rowguid,
           ModifiedDate
	FROM Production.Product
END
GO
