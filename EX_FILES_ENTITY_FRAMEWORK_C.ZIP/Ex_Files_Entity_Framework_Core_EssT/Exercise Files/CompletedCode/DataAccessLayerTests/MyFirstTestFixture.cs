﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DataAccessLayerTests
{
    public class MyFirstTestFixture
    {

    }
}
