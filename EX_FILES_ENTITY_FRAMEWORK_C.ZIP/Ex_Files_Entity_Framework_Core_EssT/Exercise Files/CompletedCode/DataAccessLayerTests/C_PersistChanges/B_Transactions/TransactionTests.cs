﻿using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Xunit;

namespace DataAccessLayerTests.C_PersistChanges.B_Transactions
{
    public class TransactionTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public TransactionTests()
        {
            //TODO: Include Test Helpers class in project
            _context = TestHelpers.CreateContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldExecuteInATransaction()
        {
        }

        [Fact]
        public void ShouldExecuteInATransactionAcrossMultipleContexts()
        {
        }
    }
}