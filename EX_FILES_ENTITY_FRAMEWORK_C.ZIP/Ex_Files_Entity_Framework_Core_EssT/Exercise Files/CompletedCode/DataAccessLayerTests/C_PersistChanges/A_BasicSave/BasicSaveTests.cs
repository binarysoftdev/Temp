﻿using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace DataAccessLayerTests.C_PersistChanges.A_BasicSave
{
    public class BasicSaveTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public BasicSaveTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldTrackStateOfEntities()
        {
        }
        [Fact]
        public void ShouldResetStateOfEntities()
        {
        }

    }
}