﻿using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace DataAccessLayerTests.C_PersistChanges.C_Batching
{
    public class BatchingTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public BatchingTests()
        {
            _context = TestHelpers.CreateContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldBatchStatementsWhenSendingToSqlServer()
        {
        }
    }
}