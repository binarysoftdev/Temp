﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using DataAccessLayerTests.C_PersistChanges;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Xunit;

namespace DataAccessLayerTests.D_DbContextConfig
{
    public class ConnectionResiliencyTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public ConnectionResiliencyTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldRetryThenFail()
        {
        }

        [Fact]
        public void UseExplicitTransactionWithExecutionStrategy()
        {
        }

        [Fact(Skip = "For demonstration purposes only")]
        public void ShouldWrapUpdateInExecutionStrategyTransaction()
        {
        }
    }
}