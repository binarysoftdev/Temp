using System;
using System.Collections.Generic;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using DataAccessLayer.EfStructures.Extensions;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.C_FilterSortAndPage
{
    public class FilterTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public FilterTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
        [Fact]
        public void ShouldFindWithPrimaryKey()
        {
        }
        [Fact]
        public void ShouldReturnNullIfPrimaryKeyIsNotFound()
        {
        }
        [Fact]
        public void FilteringResultsWithFindComplexKey()
        {
        }

        [Fact]
        public void FilterWithSimpleWhereClause()
        {
        }
        [Fact]
        public void FilterWithMultipleStatementWhereClauses()
        {
            IQueryable<Product> query = _context.Product.Where(x => (x.MakeFlag ?? true) 
                && x.ListPrice < 100.00M && x.SellEndDate == null);
            IList<Product> prodList = query.ToList();
            Assert.Equal(26,prodList.Count);
        }

        [Fact]
        public void FilterWithBuildingWhereClauses()
        {
        }

        [Fact]
        public void SHouldBeCarefulWithOrClauses()
        {
        }

        [Fact]
        public void ShouldGetTheFirstRecord()
        {
        }

        [Fact(Skip="Executes client side")]
        public void ShouldGetTheLastRecord()
        {
        }
        [Fact]
        public void ShouldReturnNullWhenRecordNotFound()
        {
        }

        [Fact]
        public void ShouldReturnJustOneRecordWithSingle()
        {
        }
        [Fact]
        public void ShouldFailIfMoreThanOneRecordWithSingle()
        {
        }

    }

}
