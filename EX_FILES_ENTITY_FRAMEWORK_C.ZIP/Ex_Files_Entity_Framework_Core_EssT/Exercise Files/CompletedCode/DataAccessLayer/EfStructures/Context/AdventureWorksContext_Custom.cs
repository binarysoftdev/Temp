﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using DataAccessLayer.EfStructures.Entities;
using DataAccessLayer.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

namespace DataAccessLayer.EfStructures.Context
{
    public partial class AdventureWorksContext
    {
        //TODO: Add logging
        public static readonly LoggerFactory AppLoggerFactory =
            new LoggerFactory(new[] { new ConsoleLoggerProvider((_, __) => true, true) });
        //TODO: Add this
        public AdventureWorksContext()
        {

        }
        public AdventureWorksContext(DbContextOptions<AdventureWorksContext> options) : base(options)
        {
        }
        //TODO: Add ProductViewModel to DbContext
        [NotMapped]
        public DbSet<ProductViewModel> ProductViewModel { get; set; }
        //TODO: Add WhereUsedViewModel to DbContext
        [NotMapped]
        public DbSet<WhereUsedViewModel> WhereUsedViewModel { get; set; }

        //TODO: Scalar Function Mapping
        //[DbFunction(FunctionName = "ufnGetStock",Schema = "dbo")]
        public static int GetStock(int productId)
        {
            throw new NotImplementedException();
        }

        internal void AddModelBuildingConfiguration(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //var connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=AdventureWorks2016;Integrated Security=True";
                ////TODO: Add logging
                //optionsBuilder
                //    .UseLoggerFactory(AppLoggerFactory)
                //    .UseSqlServer(connectionString)
                //    .ConfigureWarnings(warnings =>
                //    {
                //        warnings.Throw(RelationalEventId.QueryClientEvaluationWarning);
                //        //warnings.Throw(CoreEventId.IncludeIgnoredWarning);
                //    });
                ////    .UseSqlServer(connectionString,
                ////        options => options.EnableRetryOnFailure())
                AdventureWorksContextDesignTimeFactory.ConfigureOptionsBuilder(optionsBuilder);
            }
        }

        internal void AddModelCreatingConfiguration(ModelBuilder modelBuilder)
        {
            //TODO: Add Scalar Function Second Way
            modelBuilder.HasDbFunction(this.GetType().GetMethod("GetStock"), options =>
            {
                options.HasSchema("dbo");
                options.HasName("ufnGetStock");
            });
            //TODO: Add Query Filter
            modelBuilder.Entity<Product>().HasQueryFilter(x => x.SellEndDate == null);

            //The following is client side execution            
            //modelBuilder.Entity<Product>().HasQueryFilter(x => !x.SellEndDate.HasValue);

        }

    }
}