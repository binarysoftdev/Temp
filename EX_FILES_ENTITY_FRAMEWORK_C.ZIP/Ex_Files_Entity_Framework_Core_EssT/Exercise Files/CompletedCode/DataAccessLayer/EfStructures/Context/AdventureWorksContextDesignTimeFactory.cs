﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace DataAccessLayer.EfStructures.Context
{
    public class AdventureWorksContextDesignTimeFactory : IDesignTimeDbContextFactory<AdventureWorksContext>
    {
        public static void ConfigureOptionsBuilder(DbContextOptionsBuilder optionsBuilder)
        {
            var connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=AdventureWorks2016;Integrated Security=True";
            //var connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=AdventureWorks2017;Integrated Security=True";
            optionsBuilder
                .UseLoggerFactory(AdventureWorksContext.AppLoggerFactory)
                //.UseSqlServer(connectionString)
                .UseSqlServer(connectionString, options =>
                    options.EnableRetryOnFailure())
                  //  options.ExecutionStrategy(c=>new MyExecutionStrategy(c,3, TimeSpan.FromSeconds(10.0))))
                  //.EnableSensitiveDataLogging()
                .ConfigureWarnings(warnings =>
                {
                    warnings.Throw(RelationalEventId.QueryClientEvaluationWarning);
                    //warnings.Throw(CoreEventId.IncludeIgnoredWarning);
                });
        }

        public static DbContextOptionsBuilder<AdventureWorksContext> CreateOptionsBuilder()
        {
            var optionsBuilder = new DbContextOptionsBuilder<AdventureWorksContext>();
            ConfigureOptionsBuilder(optionsBuilder);
            return optionsBuilder;
        }

        public static AdventureWorksContext CreateDbContext()
        {
            return new AdventureWorksContext(CreateOptionsBuilder().Options);
        }

        public AdventureWorksContext CreateDbContext(string[] args)
        {
            //Args property is not used by EF Core at this time
            return new AdventureWorksContext(CreateOptionsBuilder().Options);
        }
    }
}