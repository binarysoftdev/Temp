﻿using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using Xunit;

namespace DataAccessLayerTests.B_AdvancedQueries.B_ClientServerEval
{
    public class ClientServerEvaluationTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public ClientServerEvaluationTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
        //Add warning as error to onconfiguring
        [Fact]
        public void ShouldExecuteClientSide()
        {
            //Assert.Throws<InvalidOperationException>(
            //    () => _context.Product.Average(x => x.ListPrice));
            var list = _context.Product.Where(x => !x.SellEndDate.HasValue).ToList();
        }

        [Fact]
        public void ShouldExecuteServerSide()
        {
            decimal avg = _context.Product
                .Average(x => (decimal?)x.ListPrice) ?? 0;
        }

    }
}