﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.G_RelatedData
{
    public class EagerLoadRelatedDataTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public EagerLoadRelatedDataTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldNotLoadRelatedDataByDefault()
        {
            List<Product> products = _context.Product
                .Where(x => x.ProductModelId == 7).ToList();
            Assert.Null(products[0].ProductModel);

        }
        [Fact]
        public void ShouldEagerlyLoadRelatedData()
        {
            List<Product> products = _context.Product
                .Where(x => x.ProductModelId == 7)
                .Include(x=>x.ProductModel).ThenInclude(x=>x.ProductModelIllustration)
                .ToList();
            Assert.NotNull(products[0].ProductModel);
        }
        [Fact]
        public void ShouldEagerlyLoadMultipleLevelsRelatedData()
        {
            List<Product> productList = _context.Product
                    .Where(x => x.ProductModelId == 7)
                    .Include(x => x.ProductModel).ThenInclude(x => x.ProductModelIllustration).ThenInclude(x => x.Illustration)
                    .Include(x => x.ProductCostHistory)
                    .ToList();
            Assert.NotNull(productList[0].ProductModel.ProductModelIllustration.ToList()[0].Illustration);

        }
        [Fact]
        public void ShouldIgnoreIncludeWithProjections()
        {
            var query = _context.Product
                    .Where(x => x.ProductModelId == 7)
                    .Include(x => x.ProductModel).ThenInclude(x => x.ProductModelIllustration)
                    .ThenInclude(x => x.Illustration)
                    .Include(x => x.ProductCostHistory);
            var productList = query
                .Select(x => new
                {
                    x.ProductId,
                    x.Name,
                    x.ListPrice
                })
                .ToList();

        }

        [Fact]
        public void ShouldReattachRelatedEntries()
        {
            Product prod = _context.Product.FirstOrDefault(x => x.ProductModelId == 7);
            Assert.Null(prod.ProductModel);
            ProductModel productModel = _context.ProductModel.FirstOrDefault(x => x.ProductModelId == 7);
            Assert.NotNull(prod.ProductModel);

        }
    }
}
