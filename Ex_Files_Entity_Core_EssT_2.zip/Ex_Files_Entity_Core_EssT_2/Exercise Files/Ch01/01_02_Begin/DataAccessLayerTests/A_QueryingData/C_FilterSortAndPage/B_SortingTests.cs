using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.C_FilterSortAndPage
{
    public class SortingTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public SortingTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldSortData()
        {
            IOrderedQueryable<Product> query = _context.Product
                .Where(x => x.ListPrice != 0)
                .OrderBy(x => x.ListPrice)
                .ThenByDescending(x => x.DaysToManufacture)
                .ThenBy(x => x.Name);
            var prodList = query.ToList();
            for (int x = 1; x < prodList.Count; x++)
            {
                Assert.True(prodList[x].ListPrice >= prodList[x - 1].ListPrice);
                if (prodList[x].ListPrice == prodList[x - 1].ListPrice)
                {
                    Assert.True(String.Compare(prodList[x - 1].Name, prodList[x - 1].Name, StringComparison.OrdinalIgnoreCase) <= 0);
                }
            }


        }
    }
}