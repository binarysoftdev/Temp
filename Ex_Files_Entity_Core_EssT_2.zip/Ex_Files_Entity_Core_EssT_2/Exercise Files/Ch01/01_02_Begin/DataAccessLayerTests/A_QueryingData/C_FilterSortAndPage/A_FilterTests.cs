using System;
using System.Collections.Generic;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.EfStructures.Entities;
using DataAccessLayer.EfStructures.Extensions;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.C_FilterSortAndPage
{
    public class FilterTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public FilterTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
        [Fact]
        public void ShouldFindWithPrimaryKey()
        {
            Product prod = _context.Product.Find(3);
            Assert.Equal("BB Ball Bearing", prod.Name,ignoreCase:true);
            //This will not execute a query, since entity is already tracked
            Product prod2 = _context.Product.Find(3);
            Assert.Equal("BB Ball Bearing", prod.Name, ignoreCase: true);
        }
        [Fact]
        public void ShouldReturnNullIfPrimaryKeyIsNotFound()
        {
            Product prod = _context.Product.Find(-1);
            Assert.Null(prod);
        }
        [Fact]
        public void FilteringResultsWithFindComplexKey()
        {

            ProductVendor productVendor = _context.ProductVendor.Find(2, 1688);
            Assert.Equal(5, productVendor.MaxOrderQty);
            Assert.Equal(3, productVendor.OnOrderQty);
        }

        [Fact]
        public void FilterWithSimpleWhereClause()
        {
            List<Product> prodList = _context.Product
                .Where(x => (x.MakeFlag ?? true) && x.SellEndDate == null).ToList();
            Assert.Equal(163, prodList.Count);
        }
        [Fact]
        public void FilterWithMultipleStatementWhereClauses()
        {
            List<Product> prodList = _context.Product
                .Where(x => (x.MakeFlag ?? true) && (x.SellEndDate == null
                || x.ListPrice < 100M)).ToList();
            Assert.Equal(163, prodList.Count);
        }

        [Fact]
        public void FilterWithBuildingWhereClauses()
        {
            IQueryable<Product> query = _context.Product
                .Where(x => x.SellEndDate == null);
            query = query.Where(x => x.MakeFlag ?? true);
            Assert.Equal(163, query.ToList().Count);
        }

        [Fact]
        public void ShouldBeCarefulWithOrClauses()
        {
            IQueryable<Product> query2 = _context
                .Product
                .Where(x => (x.MakeFlag ?? true) || x.ListPrice != 0 
                    && x.ListPrice < 100.00M && x.SellEndDate == null);
            var s2 = query2.ToSql();
            /*
            WHERE [SellEndDate] IS NULL AND 
            (
                COALESCE([MakeFlag], 1) = 1 OR 
                (
                ([ListPrice] <> 0.0 AND [ListPrice] < 100.0) AND [SellEndDate] IS NULL
                )
            )
            */
            IQueryable<Product> query = _context.Product
                .Where(x => (x.MakeFlag ?? true) || x.ListPrice != 0);
            query = query.Where(x => x.ListPrice < 100.00M && x.SellEndDate == null);
            var s = query.ToSql();
            /* 
             WHERE (
                [SellEndDate] IS NULL AND (COALESCE([MakeFlag], 1) = 1 OR [ListPrice] <> 0.0)) 
             AND ([ListPrice] < 100.0 AND [SellEndDate] IS NULL)
             */

        }
        [Fact]
        public void FilterWithListOfIds()
        {
            List<int> list = new List<int> {1, 3, 5};
            var query = _context.Product.Where(x => list.Contains(x.ProductId));
            var results = query.ToList();
            Assert.Equal(2, results.Count);
        }

        [Fact]
        public void ShouldGetTheFirstRecord()
        {
            Product prod = _context.Product.FirstOrDefault(x => x.MakeFlag ?? true);
            //Product prod = _context.Product.Where(x => x.MakeFlag ?? true).FirstOrDefault();
            Assert.Equal("BB Ball Bearing", prod.Name, ignoreCase: true);
        }

        [Fact]
        public void ShouldThrowWhenFirstFails()
        {
            var ex = Assert.Throws<InvalidOperationException>(
                () => _context.Product.First(x => x.ProductId == -1));
            Assert.Equal("Sequence contains no elements", ex.Message);
        }

        [Fact(Skip="Executes client side")]
        //[Fact]
        public void ShouldGetTheLastRecord()
        {
            Product prod = _context.Product.LastOrDefault(x => x.MakeFlag ?? true);
            Assert.Equal("Road-750 Black, 52", prod.Name);
        }
        [Fact]
        public void ShouldReturnNullWhenRecordNotFound()
        {
            var prod = _context.Product.FirstOrDefault(x => x.ProductId == -1);
            Assert.Null(prod);
        }

        [Fact]
        public void ShouldReturnJustOneRecordWithSingle()
        {
            Product prod = _context.Product.SingleOrDefault(x => x.ProductId == 3);
            Assert.Equal("BB Ball Bearing", prod.Name);
        }
        [Fact]
        public void ShouldFailIfMoreThanOneRecordWithSingle()
        {
            var ex = Assert.Throws<InvalidOperationException>(
                () => _context.Product.Single(x => x.MakeFlag ?? true));
            Assert.Equal("Sequence contains more than one element", ex.Message);
        }

    }

}
