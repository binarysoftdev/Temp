﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using DataAccessLayer.ViewModels;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.F_AggregatesAndProjections
{
    public class ProjectionTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public ProjectionTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldCreateNewAnonymousObjects()
        {
            var newObjectList = _context.Product
                .Where(x => x.MakeFlag ?? true)
                .Select(x=> new
                {
                    x.ProductId,
                    x.Name,
                    x.ListPrice
                })
                .OrderBy(x=>x.Name)
                .ToList();
            Assert.Equal(163, newObjectList.Count);
            Assert.Equal(3, newObjectList[0].ProductId);
        }

        [Fact]
        public void ShouldCreateNewViewModels()
        {
            List<ProductViewModel> newObjectList =
                _context.Product
                    .Where(x => x.MakeFlag ?? true)
                    .Select(x =>
                        new ProductViewModel
                        {
                            ProductId = x.ProductId,
                            Name = x.Name,
                            ListPrice = x.ListPrice,
                            Color = x.Color,
                            Size = x.Size,
                            StandardCost = x.StandardCost
                        })
                    .ToList();
            Assert.Equal(163, newObjectList.Count);
            Assert.Equal(3, newObjectList[0].ProductId);

        }
    }
}
