﻿using System;
using System.Linq;
using DataAccessLayer.EfStructures.Context;
using Xunit;

namespace DataAccessLayerTests.A_QueryingData.F_AggregatesAndProjections
{
    public class AggregateTests : IDisposable
    {
        private readonly AdventureWorksContext _context;

        public AggregateTests()
        {
            _context = new AdventureWorksContext();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        [Fact]
        public void ShouldCalculateSumOfPrices()
        {
            decimal sum = _context.Product
                .Sum(x => x.ListPrice);
            Assert.Equal(130875.72M,sum);
        }
        [Fact]
        public void ShouldCalculateCountOfNonZeroPrices()
        {
            //int count = _context.Product.Where(x => x.ListPrice != 0).Count();
            int count = _context.Product.Count(x => x.ListPrice != 0);
            Assert.Equal(206,count);

        }

        [Fact]
        public void ShouldCalculateTheAverageListPriceOfNonZeroPrices()
        {
            //decimal avg = _context.Product.Where(x => x.ListPrice != 0)
            //    .Average(x=>x.ListPrice);
            //Convert to nullable decimal so EF thinks it's a server side execution
            decimal avg = _context.Product.Where(x => x.ListPrice != 0)
                .Average(x=>(decimal?)x.ListPrice)??0;
            Assert.Equal(635.319029M, avg);
        }

        [Fact]
        public void ShouldCalculateTheMaxListPrice()
        {
            //Converting to nullable enables query to run server side
            decimal max = _context.Product.Where(x => x.ListPrice != 0)
                .Max(x => (decimal?)x.ListPrice) ?? 0;
            Assert.Equal(2443.35M, max);
        }

        [Fact]
        public void ShouldCalculateTheMinListPrice()
        {
            //Converting to nullable enables query to run server side
            decimal min = _context.Product.Where(x => x.ListPrice != 0)
                .Min(x => (decimal?)x.ListPrice) ?? 0;
            Assert.Equal(2.29M, min);
        }


        [Fact]
        public void ShouldDetermineIfAnyExistWithListPriceNotZero()
        {
            bool any = _context.Product.Any(x => x.ListPrice != 0);
            Assert.True(any);
        }

        [Fact]
        public void ShouldDetermineIfAllHaveListPriceNotZero()
        {
            bool all = _context.Product.All(x => x.ListPrice != 0);
            Assert.False(all);
        }
    }
}