using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using DataAccessLayer.EfStructures.Entities;
using DataAccessLayer.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

namespace DataAccessLayer.EfStructures.Context
{
    public partial class AdventureWorksContext
    {
        [DbFunction(FunctionName = "ufnGetStock", Schema = "dbo")]
        public static int GetStock(int productId)
        {
            throw new NotImplementedException();
        }
        [NotMapped]
        public DbSet<ProductViewModel> ProductViewModel { get; set; }
        [NotMapped]
        public DbSet<WhereUsedViewModel> WhereUsedViewModel { get; set; }

        public static readonly LoggerFactory AppLoggerFactory =
            new LoggerFactory(new [] {new ConsoleLoggerProvider((_, __) => true, true)});

        internal void AddModelCreatingConfiguration(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasQueryFilter(x => x.SellEndDate == null);
            //The following is client side evaluate
            //modelBuilder.Entity<Product>()
            //    .HasQueryFilter(x => x.SellEndDate.HasValue);

            //modelBuilder.HasDbFunction(this.GetType().GetMethod("GetStock"),
            //    options =>
            //    {
            //        options.HasSchema("dbo");
            //        options.HasName("ufnGetStock");
            //    });

        }
    }
}
