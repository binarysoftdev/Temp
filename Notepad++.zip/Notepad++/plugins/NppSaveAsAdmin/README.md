# NppSaveAsAdmin
Notepad++ Plugin nppSaveAsAdmin

Allows to save file as administrator with UAC prompt.

## Installation
Unpack to "%APPDATA%/Notepad++/plugins" to install


## Build Status
AppVeyor `VS2017`  [![Build status](https://ci.appveyor.com/api/projects/status/5886r5k7vu75qkdj?svg=true)](https://ci.appveyor.com/project/Hsilgos/nppsaveasadmin)